def something():
    return __salt__['cmd.run']('date')
